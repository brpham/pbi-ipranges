The purpose of this code is to get the current weeks listing of Azure Services and their associated IP Ranges and update existing Azure Service Firewall Rules
